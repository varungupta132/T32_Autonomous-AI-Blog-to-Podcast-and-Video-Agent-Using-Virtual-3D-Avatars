"""
🎙️ INTERACTIVE PODCAST STUDIO - EDGE TTS (Microsoft)
Professional web-based podcast generator with NATURAL voices
FREE, unlimited, and works on CPU!

Author: AI Assistant  
Date: March 7, 2026
"""

import re
import json
from pathlib import Path
from datetime import datetime
from flask import Flask, render_template, request, jsonify, send_file
import edge_tts
import asyncio
import os
from concurrent.futures import ThreadPoolExecutor, as_completed

# ============================================================================
# CONFIGURATION
# ============================================================================

# EdgeTTS voices - Natural Microsoft voices (FREE!)
VOICE_LIBRARY = {
    "speaker_1": {
        "voice": "en-IN-PrabhatNeural",  # Indian Male
        "name": "Prabhat (Indian Male - Natural)",
        "rate": "+0%",
        "pitch": "+0Hz"
    },
    "speaker_2": {
        "voice": "en-IN-NeerjaNeural",  # Indian Female
        "name": "Neerja (Indian Female - Expressive)",
        "rate": "+0%",
        "pitch": "+0Hz"
    },
    "speaker_3": {
        "voice": "hi-IN-MadhurNeural",  # Hindi Male
        "name": "Madhur (Hindi Male)",
        "rate": "+0%",
        "pitch": "+0Hz"
    },
    "speaker_4": {
        "voice": "hi-IN-SwaraNeural",  # Hindi Female
        "name": "Swara (Hindi Female)",
        "rate": "+0%",
        "pitch": "+0Hz"
    },
}

OUTPUT_DIR = Path("generated_podcasts")
TEMP_DIR = Path("temp_audio")

# Create directories
OUTPUT_DIR.mkdir(exist_ok=True)
TEMP_DIR.mkdir(exist_ok=True)

# ============================================================================
# FLASK APP
# ============================================================================

app = Flask(__name__)

# ============================================================================
# CORE FUNCTIONS
# ============================================================================

def parse_script(script):
    """Parse script and extract speakers with dialogues"""
    dialogues = []
    lines = script.strip().split('\n')
    
    for line in lines:
        line = line.strip()
        if ':' in line and len(line) > 5:
            parts = line.split(':', 1)
            if len(parts) == 2:
                speaker = parts[0].strip()
                dialogue = parts[1].strip()
                if dialogue:
                    dialogues.append({"speaker": speaker, "text": dialogue})
    
    return dialogues

def detect_speakers(dialogues):
    """Detect unique speakers and assign voices"""
    speakers = list(set([d["speaker"] for d in dialogues]))
    speakers.sort()
    
    voice_keys = list(VOICE_LIBRARY.keys())
    speaker_voices = {}
    
    for i, speaker in enumerate(speakers):
        voice_key = voice_keys[i % len(voice_keys)]
        speaker_voices[speaker] = {
            "voice_key": voice_key,
            "voice_info": VOICE_LIBRARY[voice_key]
        }
    
    return speaker_voices

def analyze_emotion(text):
    """Detect emotion for voice modulation"""
    text_lower = text.lower()
    
    if any(word in text_lower for word in ['wow', 'amazing', 'incredible', 'awesome', 'fantastic', 
                                             'zabardast', 'kya baat', '!!', 'bahut accha']):
        return "excited"
    elif '?' in text or any(word in text_lower for word in ['kya', 'really', 'sach', 'how', 'why']):
        return "curious"
    elif any(word in text_lower for word in ['important', 'must', 'critical', 'zaruri', 'bilkul']):
        return "emphasis"
    elif any(word in text_lower for word in ['think', 'believe', 'perhaps', 'maybe', 'shayad']):
        return "thoughtful"
    
    return "neutral"

def get_voice_params(emotion):
    """Get voice parameters based on emotion"""
    params = {
        "excited": {"rate": "+15%", "pitch": "+5Hz"},
        "curious": {"rate": "+5%", "pitch": "+3Hz"},
        "emphasis": {"rate": "+0%", "pitch": "+2Hz"},
        "thoughtful": {"rate": "-10%", "pitch": "-2Hz"},
        "neutral": {"rate": "+0%", "pitch": "+0Hz"}
    }
    return params.get(emotion, params["neutral"])

async def generate_audio_async(text, voice, rate, pitch, output_path):
    """Generate audio using EdgeTTS"""
    communicate = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch)
    await communicate.save(str(output_path))

def generate_audio_segment(speaker_voice, text, output_path):
    """Generate audio segment with emotion"""
    try:
        voice_info = speaker_voice["voice_info"]
        emotion = analyze_emotion(text)
        params = get_voice_params(emotion)
        
        # Create new event loop for this thread
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        
        try:
            loop.run_until_complete(generate_audio_async(
                text=text,
                voice=voice_info["voice"],
                rate=params["rate"],
                pitch=params["pitch"],
                output_path=output_path
            ))
        finally:
            loop.close()
        
        return output_path, emotion
    
    except Exception as e:
        print(f"Error generating audio: {str(e)}")
        raise

def merge_audio_files(audio_files, output_file):
    """Merge audio files"""
    with open(output_file, 'wb') as outfile:
        for mp3_file in audio_files:
            if os.path.exists(mp3_file):
                with open(mp3_file, 'rb') as infile:
                    outfile.write(infile.read())
    return output_file

# ============================================================================
# API ROUTES
# ============================================================================

@app.route('/')
def index():
    """Serve main page"""
    return render_template('index.html')

@app.route('/api/analyze', methods=['POST'])
def analyze_script():
    """Analyze script and detect speakers"""
    try:
        data = request.json
        script = data.get('script', '')
        
        if not script:
            return jsonify({"error": "No script provided"}), 400
        
        dialogues = parse_script(script)
        
        if not dialogues:
            return jsonify({"error": "No valid dialogues found. Format: Speaker: Dialogue"}), 400
        
        speaker_voices = detect_speakers(dialogues)
        
        return jsonify({
            "success": True,
            "total_dialogues": len(dialogues),
            "speakers": len(speaker_voices),
            "speaker_info": {
                speaker: {
                    "voice": info["voice_info"]["name"],
                    "engine": "Microsoft EdgeTTS (FREE)"
                }
                for speaker, info in speaker_voices.items()
            },
            "dialogues": dialogues
        })
    
    except Exception as e:
        print(f"Error in analyze_script: {str(e)}")
        return jsonify({"error": str(e)}), 500

@app.route('/api/generate', methods=['POST'])
def generate_podcast():
    """Generate podcast with EdgeTTS - PARALLEL processing"""
    try:
        data = request.json
        script = data.get('script', '')
        podcast_name = data.get('name', f'podcast_{datetime.now().strftime("%Y%m%d_%H%M%S")}')
        
        podcast_name = re.sub(r'[^\w\-_]', '_', podcast_name)
        
        if not script:
            return jsonify({"error": "No script provided"}), 400
        
        print(f"\n{'='*60}")
        print(f"🎙️ EDGE TTS PODCAST GENERATION - FREE & NATURAL")
        print(f"{'='*60}\n")
        
        dialogues = parse_script(script)
        if not dialogues:
            return jsonify({"error": "No valid dialogues found"}), 400
            
        speaker_voices = detect_speakers(dialogues)
        
        print(f"📊 Total dialogues: {len(dialogues)}")
        print(f"🎤 Speakers: {len(speaker_voices)}")
        print(f"⚡ Using parallel generation\n")
        
        # Prepare tasks
        tasks = []
        for i, dialogue in enumerate(dialogues):
            speaker = dialogue["speaker"]
            text = dialogue["text"]
            output_path = TEMP_DIR / f"{podcast_name}_seg_{i:03d}_{speaker}.mp3"
            
            tasks.append({
                "index": i,
                "speaker": speaker,
                "text": text,
                "output_path": output_path,
                "voice": speaker_voices[speaker]
            })
        
        audio_files = [None] * len(tasks)
        progress_data = []
        import time
        start_time = time.time()
        
        def generate_segment(task):
            """Worker function"""
            try:
                idx = task["index"]
                speaker = task["speaker"]
                text = task["text"]
                output_path = task["output_path"]
                voice = task["voice"]
                
                print(f"[{idx+1}/{len(tasks)}] 🎵 {speaker}: {text[:40]}...")
                
                _, emotion = generate_audio_segment(voice, text, output_path)
                
                if output_path.exists():
                    print(f"[{idx+1}/{len(tasks)}] ✓ Done ({emotion})")
                    return {
                        "success": True,
                        "index": idx,
                        "path": output_path,
                        "speaker": speaker,
                        "emotion": emotion,
                        "text": text
                    }
                else:
                    return {"success": False, "index": idx, "error": "File not created"}
                    
            except Exception as e:
                print(f"[{idx+1}/{len(tasks)}] ✗ Error: {str(e)}")
                return {"success": False, "index": idx, "error": str(e)}
        
        # Parallel processing
        max_workers = min(len(tasks), 8)
        
        with ThreadPoolExecutor(max_workers=max_workers) as executor:
            future_to_task = {executor.submit(generate_segment, task): task for task in tasks}
            
            for future in as_completed(future_to_task):
                result = future.result()
                
                if result["success"]:
                    idx = result["index"]
                    audio_files[idx] = result["path"]
                    progress_data.append({
                        "index": idx + 1,
                        "speaker": result["speaker"],
                        "emotion": result["emotion"],
                        "text": result["text"][:60] + "..." if len(result["text"]) > 60 else result["text"]
                    })
                else:
                    return jsonify({"error": f"Failed segment {result['index']+1}"}), 500
        
        audio_files = [f for f in audio_files if f is not None]
        
        if not audio_files:
            return jsonify({"error": "No audio files generated"}), 500
        
        print(f"\n🎧 Merging {len(audio_files)} segments...")
        
        output_file = OUTPUT_DIR / f"{podcast_name}.mp3"
        merge_audio_files(audio_files, output_file)
        
        if not output_file.exists():
            return jsonify({"error": "Failed to create final file"}), 500
        
        # Cleanup
        for file in audio_files:
            try:
                if file.exists():
                    file.unlink()
            except:
                pass
        
        file_size = output_file.stat().st_size / 1024 / 1024
        
        print(f"\n{'='*60}")
        print(f"✓ SUCCESS! {output_file.name}")
        print(f"  Size: {file_size:.2f} MB")
        print(f"  Segments: {len(audio_files)}")
        print(f"{'='*60}\n")
        
        progress_data.sort(key=lambda x: x["index"])
        
        return jsonify({
            "success": True,
            "filename": output_file.name,
            "file_size": f"{file_size:.2f} MB",
            "total_segments": len(audio_files),
            "speakers": len(speaker_voices),
            "progress": progress_data
        })
    
    except Exception as e:
        print(f"\n✗ ERROR: {str(e)}")
        import traceback
        traceback.print_exc()
        return jsonify({"error": str(e)}), 500

@app.route('/api/download/<filename>')
def download_podcast(filename):
    """Download generated podcast"""
    try:
        file_path = OUTPUT_DIR / filename
        if file_path.exists():
            return send_file(file_path, as_attachment=True)
        return jsonify({"error": "File not found"}), 404
    except Exception as e:
        return jsonify({"error": str(e)}), 500

@app.route('/api/voices')
def get_voices():
    """Get available voices"""
    return jsonify({
        "voices": [
            {
                "key": key,
                "name": info["name"],
                "voice_id": info["voice"]
            }
            for key, info in VOICE_LIBRARY.items()
        ]
    })

# ============================================================================
# MAIN
# ============================================================================

if __name__ == '__main__':
    print("\n" + "="*60)
    print("🎙️  PODCAST STUDIO - MICROSOFT EDGE TTS")
    print("="*60)
    print("\n🚀 Starting server...")
    print("📱 Open: http://localhost:8080")
    print("\n✨ Features:")
    print("   • 100% FREE - Unlimited usage!")
    print("   • Natural Microsoft voices")
    print("   • Indian accent support")
    print("   • Hindi & Hinglish perfect")
    print("   • Emotion-based modulation")
    print("   • ⚡ Fast parallel generation")
    print("\n💡 Using Microsoft EdgeTTS - Professional quality!")
    print("🎧 Works on CPU - No GPU needed!")
    print("\n" + "="*60 + "\n")
    
    app.run(debug=True, host='0.0.0.0', port=8080)
